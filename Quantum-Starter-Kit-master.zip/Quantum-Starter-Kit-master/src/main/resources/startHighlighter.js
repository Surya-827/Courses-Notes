document.perfectoViolationHighlighter = new document.AxeResultHelper(document.perfectoAxeResults, '%s');
return true;
